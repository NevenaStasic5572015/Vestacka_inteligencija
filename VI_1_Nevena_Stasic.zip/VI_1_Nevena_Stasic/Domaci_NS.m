clear all
close all
clc

%% Ucitavanje podataka

load podaci_557.mat

X = data(1:2,:);
Y = data(3,:);

X_0 = X(:,Y==0);
X_1 = X(:,Y==1);


%% Prikaz podataka

figure()
hold all
scatter(X_0(1, :), X_0(2, :), 'r.')
scatter(X_1(1, :), X_1(2, :), 'b.')
xlabel('x_1')
ylabel('x_2')
title('Podaci')
legend('Klasa 0', 'Klasa 1')


%% Slucajna podela podataka na trening i test skup
ind = randperm(length(X));
br = round(0.9*length(ind));

X_train = X(:, ind(1 : br));
Y_train = Y(ind(1 : br));

X_test = X(:, ind(br + 1 : end));
Y_test = Y(ind(br + 1 : end));


%% Prikaz podele
X_train_0 = X_train(:, Y_train == 0);
X_train_1 = X_train(:, Y_train == 1);
X_test_0 = X_test(:, Y_test == 0);
X_test_1 = X_test(:, Y_test == 1);

% Klasa 0
figure()
hold all
scatter(X_train_0(1, :) , X_train_0(2, :), 'k.')
scatter(X_test_0(1, :), X_test_0(2, :), 'mx')
xlabel('x_1')
ylabel('x_2')
title('Klasa 1')
legend('trening','test')

% Klasa 1
figure()
hold all
scatter(X_train_1(1, :) , X_train_1(2, :), 'k.')
scatter(X_test_1(1, :), X_test_1(2, :), 'mx')
xlabel('x_1')
ylabel('x_2')
title('Klasa 2')
legend('trening','test')
net = feedforwardnet([4,3]);
net.divideParam.trainRatio = 1;
net.divideParam.valRatio = 0;
net.divideParam.testRatio = 0;
net.Layers{3}.transferFcn = 'tansig';
net.trainParam.epochs = 1000; 
net.trainParam.goal = 1e-5;
[net, tr] = train(net, X_train, Y_train);
izlaz_trening = sim(net, X_train);
izlaz_test = sim(net, X_test);
view(net);
net.trainparam.showWindow = false;

figure('Name','Trening izlaz','NumberTitle','off')  
for i = 1 : length(X_train)
   if izlaz_trening(i) <= 0.3   
       izlaz1 = plot(X_train(1, i), X_train(2, i), 'mh');hold on
   elseif izlaz_trening(i) >= 0.7 
       izlazt = plot(X_train(1, i), X_train(2, i), 'gx');hold on
   else
       izlaz3 = plot(X_train(1, i), X_train(2, i), 'b.');hold on 
   end
end
title('Trening izlaz')
xlabel('x')
ylabel('y')
legend([izlaz1, izlazt, izlaz3])

figure('Name','Test izlaz','NumberTitle','off')  
for i = 1 : length(X_test)
   if izlaz_test(i) <= 0.3   
       izlaz4 = plot(X_test(1, i), X_test(2, i), 'mh');hold on
   elseif izlaz_test(i) >= 0.7  
       izlazz = plot(X_test(1, i), X_test(2, i), 'gx');hold on
   else
       izlaz6 = plot(X_test(1, i), X_test(2, i), 'b.');hold on
   end
end
title('Test izlaz')
xlabel('x')
ylabel('y')
legend([izlaz4, izlazz, izlaz6])
figure
plotperform(tr);
figure
plottrainstate(tr);

figure
plotconfusion(Y_train, izlaz_trening)

figure
plotconfusion(Y_test, izlaz_test) 

[C1,CM1,~,~] = confusion(Y_train, izlaz_trening); 
[C2,CM2,~,~] = confusion(Y_test, izlaz_test); 
tacnost = (1 - C1)*100;
tacnostt = (1 - C2)*100;
preciznost = 100*CM1(2,2)/(CM1(2,1) + CM1(2,2));
preciznostt = 100*CM2(2,2)/(CM2(2,1) + CM2(2,2));
recall = 100*CM1(2,2)/(CM1(1,2) + CM1(2,2));
recalll = 100*CM2(2,2)/(CM2(1,2) + CM2(2,2));
F1 = ( 2 * preciznost * recall ) / ( preciznost + recall ); 
F1_Test = ( 2 * preciznostt * recalll ) / ( preciznostt + recalll );





%Podaci za treniranje
train_data = [X_train; Y_train];
save('train_data.mat', 'train_data')

%Podaci za testiranje
test_data = [X_test; Y_test];
save('test_data.mat', 'test_data')

